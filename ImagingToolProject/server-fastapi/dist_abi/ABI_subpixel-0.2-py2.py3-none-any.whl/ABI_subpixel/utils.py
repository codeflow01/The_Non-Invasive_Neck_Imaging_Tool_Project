import cv2
import csv
import numpy as np

from datetime import datetime


def read_image(floc):
    """
    Helper function to ensure images can be read in with just the project
    Args:
        floc: the file location
    Returns:

    """
    if not isinstance(floc, str):
        raise ValueError('Pass the file location of the image')
    im = cv2.imread(floc)
    if im is None:
        raise ValueError('Image was not found at this location')

    return im

def save_results(results, locs, run_params=None, filename=None):
    """
    A function to save results to a csv
    Returns:
    """

    now = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

    if filename is None:
        filename = str(now) + '_results.csv'

    with open(filename, mode='w') as r_file:
        r_writer = csv.writer(r_file, delimiter=',', quotechar="'")

        # header component
        r_writer.writerow(['Date Generated', str(now)])
        # 'csv description
        if run_params is not None:
            for key, value in run_params.items():
                if value is not None:
                    r_writer.writerow([key, value])

        r_writer.writerow(['x_loc', 'y_loc', 'x_shift', 'y_shift'])

        for loc, shift in zip(locs, results.squeeze()):
            r_writer.writerow([loc[0], loc[1], shift[0], shift[1]])




def downsample_valid(inp, d_factor, invalid=None):
    """

    Args:
        inp: The input to be be downsampled
        d_factor: The factor to downsample
        invalid: The value of points to be excluded from the downsampling in the function

    Returns:
        For a point with inputs, returns the average of the valid inputs
        For a point without valid inputs, returns the value of the invalid inputs
        Returned object has no singleton dimensions

    """
    if d_factor == 1:
        return inp

    shape = np.array(inp.shape)
    rem = shape % d_factor
    up_to = shape - rem

    im = inp[:up_to[0], :up_to[1]]

    return np.mean(im.reshape(im.shape[0]//d_factor, d_factor, im.shape[
        1]//d_factor, d_factor), axis=(1, 3))

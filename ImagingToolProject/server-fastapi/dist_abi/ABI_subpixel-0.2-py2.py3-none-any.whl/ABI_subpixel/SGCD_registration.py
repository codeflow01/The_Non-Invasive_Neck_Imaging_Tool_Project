import numpy as np
import logging

from scipy.signal import convolve2d as cov2d
from matplotlib import pyplot as plt

def preprocessing(ims):
    '''

    :param im: the image to preprocess
    :return:
    '''
    if ims[0].ndim == 3: #take the first channel for multichannel images
        ims = [im[:, :, 0] for im in ims]
    ims = SG_convolution(ims)
    return ims

def SG_convolution(ims):
    # define the kernel
    kernel = 1 / 252 * np.array([[22, -67, -58, 0, 58, 67, -22]])  # the gradient kernel we care about
    #return as a complex array

    convolution = cov2d(ims, kernel, mode='same', fillvalue=0, boundary='symm') \
                        + 1j*cov2d(ims.T, kernel, mode='same', fillvalue=0, boundary='symm').T

    return convolution


def CPS_function(im1, im2):
    # take the conjugate
    res = ((im1*np.conj(im2)))
    res /= np.abs(res)
    # inversefft
    corrMat = np.abs(np.fft.fftshift(np.fft.ifft2(res)))
    # take the peak
    max = np.array(np.unravel_index(np.argmax(corrMat), shape=res.shape)) - [32,32]

    # return peak/median as well
    snr = np.max(corrMat) #/np.median(corrMat) just return the signal amplitude
    print(snr)
    return max, snr


def CPS_stack(image_stack, comps, images, offsets, num):
    """
    Notes: first image in the list is the image to compare against.
        Implementation of the stack function, except taking advantage of vectorised code to do comparisons in chunks.

    Args:
        image_stack:
        comps: the comparison camera for each image point
        images: dud variable for debugging
        offsets: shifts from zero for each image component - a list
        num: the number of the comparison in each chunk of work
    Returns:
        results: the shift in each comparison

    """
    offset = image_stack[0].shape[0]//2
    cps_stack = np.conj(image_stack[1:]) * image_stack[0]
    cps_stack /= np.abs(cps_stack) + 1e-6
    corr_stack = np.abs(np.fft.fftshift(np.fft.ifft2(cps_stack), axes=(1, 2))) #watch out for fftshift, it's aggressive

    """


    fig, axes = plt.subplots(1,2)
    axes[0].imshow(images[0])
    axes[1].imshow(images[1])
    plt.show()
    plt.imshow(corr_stack[0], vmin=0, vmax=1)
    plt.show()


    #"""

    # do the coordinate correction in the shift
    #added the offsets input functionality

    loc = [np.unravel_index(np.argmax(corr_mat), shape=corr_mat.shape) for corr_mat in corr_stack]
    max_loc = np.array(loc) - [offset] * 2
    snr = np.max(corr_stack, axis=(1, 2)) #/(np.median(corr_stack, axis=(1, 2)) + 1e-6)

    data = [None]*len(set(comps))

    for idx, ind in enumerate(set(comps)):
        points = np.where(comps == ind)

        best_in_range = np.argmax(snr[points])
        data[idx] = (max_loc[points][best_in_range] - offsets[best_in_range,:],
                     snr[points][best_in_range],
                     best_in_range)



    #print(data[0])
    return data
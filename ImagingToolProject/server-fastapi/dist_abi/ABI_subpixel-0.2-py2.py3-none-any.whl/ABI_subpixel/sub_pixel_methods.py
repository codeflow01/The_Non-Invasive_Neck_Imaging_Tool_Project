import os

os.environ["OMP_NUM_THREADS"] = "1"  # export OMP_NUM_THREADS=1
os.environ["OPENBLAS_NUM_THREADS"] = "1"  # export OPENBLAS_NUM_THREADS=1
os.environ["MKL_NUM_THREADS"] = "1"  # export MKL_NUM_THREADS=1
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"  # export VECLIB_MAXIMUM_THREADS=1
os.environ["NUMEXPR_NUM_THREADS"] = "1"  # export NUMEXPR_NUM_THREADS=1

import scipy
import logging
import numpy as np
import math as m
# from numpy.linalg import svd
from scipy.linalg import svd
from scipy.optimize import curve_fit
from functools import lru_cache as cache

from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


# welcome to the dark side of the code
def complex_to_dual_real(inp):
    return np.stack((inp.real, inp.imag)).flatten()


def phase_fn(v_ind, phase):
    return complex_to_dual_real(np.exp(1j * m.pi * phase * v_ind))


def plot_phase_fn(v_ind, phase):
    return np.exp(1j * m.pi * phase * v_ind)


def debug_plotter(x1, y1, im0, im1, px, py, num):
    # print(px, py)

    h_arr = 32  # okay to hardcode this in the test result

    v_control = np.linspace(0, 1 - 1 / x1.shape[0] // 2, x1.shape[0] * 2)
    u_control = np.linspace(0, 31, 128)

    w1 = abs(x1) / (abs(np.max(abs(x1))) + 1e-12)
    w2 = abs(y1) / (abs(np.max(abs(y1))) + 1e-12)

    x1 = x1 / (abs(abs(x1)) + 1e-12)
    y1 = y1 / (abs(abs(y1)) + 1e-12)

    xf = plot_phase_fn(v_ind=v_control, phase=px[0])
    yf = plot_phase_fn(v_ind=v_control, phase=py[0])

    fig, axs = plt.subplots(2, 4)
    fig.set_size_inches(18.5, 10.5)
    # fig.set_figsize = (10,12)
    fig.suptitle('Comparison ' + str(num))

    (ax1, ax2, axim1, axang1), (ax3, ax4, axim2, axang2) = axs
    # '''
    ax1.plot(x1.real[:h_arr], '.')
    ax1.plot(x1.imag[:h_arr], '.')

    ax1.plot(u_control, xf.real)
    ax1.plot(u_control, xf.imag)
    '''
    ax1.plot(np.angle(x1),'.')
    #'''

    ax2.plot(w1[:h_arr], '.')
    ax2.set_ylim([0, 1])

    # '''
    ax3.plot(y1.real[:h_arr], '.')
    ax3.plot(y1.imag[:h_arr], '.')

    ax3.plot(u_control, yf.real)
    ax3.plot(u_control, yf.imag)
    '''
    ax3.plot(np.angle(y1))
    #'''

    # '''
    ax4.plot(w2[:h_arr], '.')
    ax4.set_ylim([0, 1])
    '''
    ax4.plot(np.angle(y1[:h_arr]),'.')

    #'''

    axim1.imshow(abs(im0), )  # vmax=255, vmin=0)

    axim2.imshow(abs(im1), )  # vmax=255, vmin=0)

    axang1.plot(np.angle(np.fft.fftshift(x1)))
    axang2.plot(np.angle(np.fft.fftshift(y1)))

    plt.show()


def CPS_to_results(cps, comp, im0, im1, num):
    edge_factor = 0
    mini_cps = cps
    # ADD a median filter to the cps
    '''
    pts = np.angle(mini_cps)
    pts = scipy.signal.medfilt2d(pts, kernel_size=5)

    mini_cps = np.cos(pts) + np.sin(pts)*1j
    #'''

    offset = mini_cps[0].shape[0] // 2
    # take the cross power spectrum

    logging.debug('Got to SVD')  # logging.debug('got up to SVD decomposition')
    U, _, V = svd(mini_cps)
    logging.debug('SVD finished')
    sx, sy = U[:, 0], V[0, :].conj()

    h_arr = sx.shape[0] // 2
    wx, wy = np.abs(np.abs(sx)) ** 2 + 1e-12, np.abs(np.abs(sy)) ** 2 + 1e-12

    # sign flip so that dc component has a value of 1, not -1 (can get flipped by the
    sx *= m.copysign(1, sx.real[0])
    sy *= m.copysign(1, sy.real[0])
    v_control = np.linspace(0, 1 - 1 / (cps.shape[0]) // 2, cps.shape[0] // 2)

    # maybe we can do a weighted average as a first estimate?
    est_px = -(np.argmax(np.fft.fftshift(np.fft.ifft(sx))) - offset)
    est_py = -(np.argmax(np.fft.fftshift(np.fft.ifft(sy))) - offset)

    '''
    plt.plot((sy/wy)[edge_factor:h_arr].imag)
    #plt.plot(np.angle(sy))
    plt.show()
    #'''

    logging.debug('Started Curve fitting')

    p_x, q_x = curve_fit(phase_fn,
                         xdata=v_control[edge_factor:],
                         ydata=complex_to_dual_real(
                             (sx / wx)[edge_factor:h_arr]),
                         p0=est_px,
                         sigma=1 / np.concatenate((wx[edge_factor:h_arr],
                                                   wx[edge_factor:h_arr]),
                                                  axis=0))

    p_y, q_y = curve_fit(phase_fn,
                         xdata=v_control[edge_factor:],
                         ydata=complex_to_dual_real(
                             (sy / wy)[edge_factor:h_arr]),
                         p0=est_py,
                         sigma=1 / np.concatenate((wy[edge_factor:h_arr],
                                                   wy[edge_factor:h_arr]),
                                                  axis=0))

    return ([-p_x[0], -p_y[0]], np.mean([q_x, q_y]), comp)


def SVD_fit(fft_stack, comps, images, offsets, num):
    comps = np.unique(comps)
    cps_stack = np.conj(fft_stack[1:]) * fft_stack[0]
    cps_stack /= np.abs(cps_stack) + 1e-12  # normalise the cross power spectrum
    results = [CPS_to_results(cps, comp, images[0], ims, num)
               for cps, comp, ims in zip(cps_stack, comps, images[1:])]
    return results


def Amir_fit(fft_stack, comps, images, offsets, num, AA=None):
    results = Amir_based_method(fft_stack[0], fft_stack[1], comps, AA=AA)
    #results = unwound_plane_fitter(fft_stack[0], fft_stack[1], comps, AA=AA)
    return [results]

@cache(maxsize=1)
def calc_AA(shape, stack_smaller=False):
    if not stack_smaller:
    # Precompute (A.T * A).I * A.T for faster processing
        tmp_A = []
        for i in range(shape[0]):
            for j in range(shape[1]):
                tmp_A.append([1, i, j])
        A = np.array(tmp_A)
        return np.linalg.inv(A.T @ A) @ A.T

    else:
        AAs = []
        for l in range(4, shape[0] + 1):
            A = calc_AA((l,l))
            base = np.zeros((3, shape[0]**2))
            base[:,:l**2] = A
            AAs.append(base)
    return np.array(AAs)




def Amir_based_method(im1, im2, comps, AA=None):
    """
    Notes: faithful implementation of Amir's method for reconstruction
    Args:
        im1: fft of im1,
        im2: fft of im2

    Returns:

    """
    scaling_af = 6
    a_f = im1.shape[0] // scaling_af
    comp = np.unique(comps)

    def amir_plane_fitter(p, AA=None):
        if AA is None:
            AA = calc_AA(p.shape)

        b = p.flatten().T
        x = AA @ b
        return x.flatten()

    Phase_img = im1 * np.conj(im2)
    Phase = np.fft.fftshift(Phase_img)

    p = np.angle(Phase)

    p1 = p[a_f:-a_f, a_f:-a_f]
    p1 = scipy.signal.medfilt2d(p1, kernel_size=5)
    p1 = p1[a_f:-a_f, a_f:-a_f]

    c, a, b = amir_plane_fitter(p1, AA)
    plot_phase = False
    if plot_phase:
        X = np.arange(0, p1.shape[1], 1)
        Y = np.arange(0, p1.shape[0], 1)
        X, Y = np.meshgrid(X, Y)

        fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

        surf = ax.plot_surface(X, Y, p1, cmap=plt.cm.coolwarm,
                               linewidth=0, antialiased=False)

        fig.colorbar(surf, shrink=0.5, aspect=5)
        plt.show()

    # decrease by the fit margin
    shifts = np.array([(p.shape[0] / (2 * np.pi)) * a,
                       (p.shape[1] / (2 * np.pi)) * b]).astype(float)
    return (np.array(shifts),), c, comp[0]


def unwound_plane_fitter(fft1, fft2, comps, AA=None,):
    """
    Notes: This defines a new method of fitting sub pixel information
    Args:
        fft1:
        fft2:
        comps:
        AA:

    Returns:

    """

    # perform the fit and the testing

    shape = fft1.shape

    phase_img = fft1 * np.conj(fft2)
    phase = np.fft.fftshift(phase_img)

    p = np.angle(phase)

    # take the bottom left corner because everything is symmetric
    p_median = scipy.ndimage.median_filter(input=p,
                                     size=5,
                                      mode='reflect',
                                     )
    p_median_2 = p_median[(shape[0] // 2):, (shape[1] // 2):]



    ind_order, poi = order_grid(p_median_2.shape)
    AA = calc_AA(p_median_2.shape, stack_smaller=True)

    p_temp = p_median_2.flatten().T
    fit_contribs = (AA @ p_temp) *  p.shape[0] /(2*np.pi)

    debug_plots=True
    if debug_plots:
        plt.close('all')
        plt.imshow(p_median)
        plt.figure()
        plt.plot(fit_contribs)
        plt.show()


@cache(maxsize=1)
def order_grid(shape):
    """
    Notes: This function orders points by minimum distance from center
    Args:
        shape: shape of the input to reorder

    Returns:
        ind: an index array of points in the new order
        bp: breakpoints to examine the points at

    """

    pts = np.stack(np.meshgrid(range(shape[0]), range(shape[1])))
    dists = np.max(pts, axis=0).flatten()
    inds = np.argsort(dists)

    #
    _, poi = np.unique(dists[inds],return_index=True)
    return inds, poi

import logging
from multiprocessing import cpu_count
from collections import defaultdict

import numpy as np
import ray
from matplotlib import pyplot as plt

from . import SGCD_registration as px
from . import sub_pixel_methods as spx


# ==============================================================================#
# This implements the frameworks for executing the registrations. Efforts are
# generally made to parallelise the inputs allowing them to be run more quickly
# Written by Robin Laven
# ==============================================================================#

# @ray.remote
def register_chunk(images, inp, window_size, comparison_fn):
    """
    Notes: This takes a segment of the parallelised work and iterates through
        its allocated search points.

    Args:
        inp: a tuple containing the search_slice of comparisons and the image
            data to perform the comparisons on
        comparison_fn: the function to be applied to all transforms

    Returns:
        comparison array results
    """
    work_list, comps, offsets = inp
    window_fn = return_hamming(window_size)
    # print('worker function started')
    if __name__ == '__main__':
        visualise(images, work_list)

    results = [register_image_set(work_item, images, window_fn, window_size,
                                  comp, comparison_fn, offset, num)
               for num, (work_item, comp, offset) in
               (enumerate(zip(work_list, comps, offsets)))]

    # print("worker function finished")
    return results


register_ray_chunk = ray.remote(register_chunk)


def visualise(ims, searchlets):
    plt.imshow(ims[0])
    for search in searchlets:
        if search[0, -1] == 0:
            plt.plot(search[0, 0], search[0, 1], 'ro')

    plt.figure()
    plt.imshow(ims[2])
    for search in searchlets:
        if search[0, -1] == 2:
            plt.plot(search[0, 0], search[0, 1], 'bo')

    plt.show()


def work_item_to_slices(work_item, window_size):
    """
    Notes: takes coordinates and returns extractable slices

    Args:
        work_item: the search_slice of top corners for the image
            sub windows to be extracted
            also contains the index of the point to be searched
        window_size: the image sub windows to be compared

    Returns:
        slices_list: a search_slice of slice lists []

    """

    def slice_pair(cord, window_size):
        x, y, i = cord
        return (slice(x, x + window_size), slice(y, y + window_size), i)

    return [slice_pair(cord, window_size) for cord in work_item]


def register_image_set(work_item, data, window_fn, window_size,
                       comps, comparison_fn, offsets, num):
    """
    Notes: Extracts, transforms and feeds the comparison function with the
        results of the transformation.

    Args:
        work_item: search_slice of top left corner indicies for comparison
        data: static data file
        comparison_fn: function to compare stack

    Returns:
        comparison results for the initial comparison

    """

    # maybe this will work here

    # for now, just extrct only from the one image.
    # more complex plans can be done soon
    slices = work_item_to_slices(work_item, window_size)

    def try_slice(slce):
        try:
            im = data[slce[-1]]
        except IndexError:
            logging.error("Requested non-existent image")
            return None, False
        try:
            window = im[slce[:-1]].astype(np.float32)
            if window.shape == window_fn.shape:
                return window, True
            else:
                padded = np.zeros_like(window_fn)
                padded[:window.shape[0], :window.shape[1]] = window
                return padded, True
        except IndexError:
            logging.error("Image slice does not contain all windows")
            return None, False

    slice_results = [try_slice(window) for window in slices]
    ims, present = list(zip(*slice_results))
    images = np.array([im for im, pres in zip(ims, present) if pres])

    try:
        images *= window_fn[np.newaxis, ...]
    except:
        logging.error("Image shape became weird ")

    im_ffts = np.fft.fft2(images)
    present = list(present)
    pres_iter = iter(present[1:])

    # actually here we want to turn the offsets into one big, flat array
    temp_offsets = []
    for cam_offset in offsets:
        for pt in cam_offset:
            if next(pres_iter):
                temp_offsets.append(pt)

    # past a list of present offsets in the images
    results = comparison_fn(im_ffts,
                            comps[present[1:]],
                            images,
                            np.array(temp_offsets),
                            num,
                            )

    # assert results[0].dtype == np.float, "Why are you giving integer shifts"

    return results


def return_hamming(inp):
    """
    Notes: Defines a hamming window because those are usefull

    Args:
        inp: dimensions of the window to make the hamming function with

    Returns:
        2d hamming window
    """
    return np.hamming(inp)[np.newaxis, ...] * np.hamming(inp)[..., np.newaxis]


def debug_quiver_plot(images,
                      searches,
                      results,
                      offsets,
                      thresh=1000,
                      mode='ref',
                      ):
    """
    Notes: A debug plotting function visuallising the detected shifts

    Args:
        images: the input image that is being searched over
        searches: the searches to run the ims over
        results: the results of the searches
        thresh: a display threshold for magnitudes of shifts

    """

    # grab the results

    if mode == 'ref':

        res = np.array([result[0][0] for result in results])
        '''
        es /= (mags[..., np.newaxis] + 1e-12)
        # clip the magnitudes to 5
        mags = np.clip(mags, a_min=0, a_max=thresh)
        res *= mags[..., np.newaxis]
        #'''
        mags = np.linalg.norm(res, axis=1)
        loc = np.array([search[0, :2] for search in searches])
        mask = mags < thresh

        im_mask = [search[0, 2] for search in searches]
        ref_ims = np.unique(im_mask)
        for im in ref_ims:
            plt.figure()
            plt.imshow(abs(images[im]), cmap='gray')

            temp_mask = (im_mask == im) & mask

            ax = plt.quiver(loc[temp_mask, 1] + 32,
                            loc[temp_mask, 0] + 32,
                            -res[temp_mask, 1],
                            res[temp_mask, 0],
                            mags[temp_mask],
                            )
            cbar = plt.colorbar(ax)
            cbar.set_label('Magnitude of shift')
            # plt.title(title)
        plt.show()
    elif mode == 'virt':
        im_mask = [np.unique(search[1:, -1]) for search in searches]
        locs = [search[1:, :2] for search in searches]
        res = [[reslet[0] for reslet in res_chunk] for res_chunk in results]

        ims = np.unique(np.block(im_mask))

        associations = defaultdict(list)

        for search in searches:
            virts = np.unique(search[1:, -1])
            for virt in virts:
                associations[virt].append(search[0, -1])

        # alternate method

        # make a default dict for location and result

        loc_dict = defaultdict(list)
        result_dict = defaultdict(list)
        offset_dict = defaultdict(list)

        for res_let, loc_let, im_let, off_let \
                in zip(res, locs, im_mask, offsets):
            for res_sing, loc_sing, im_sing, off_sing \
                    in zip(res_let, loc_let, im_let, off_let):
                loc_dict[im_sing].append(loc_sing)
                result_dict[im_sing].append(res_sing)
                offset_dict[im_sing].append(off_sing)

        for im in ims:
            alts = np.unique(associations[im])
            n_alts = len(alts)

            fig, ax = plt.subplots(1, n_alts + 1)
            for idx, alt in enumerate(alts):
                ax[idx].imshow(abs(images[alt]), cmap='gray')
                ax[idx].set_title('Reference image {}'.format(alt))

            l = np.array(loc_dict[im]).squeeze()
            r = np.array(result_dict[im]).squeeze()
            of = offset_dict[im][0][[0, -1], :]

            # search points are in OPENCV CORDS

            plot_err = False

            if plot_err:
                # plot the shift perpendicular to the expected offset

                offsets = offset_dict[im]
                offset_vects = [n[-1,:] - n[0,:] for n in offsets]
                offf = offset_vects\
                       /np.linalg.norm(offset_vects, axis=-1)[..., None]
                #offf = [1,-1] * offf[:, [1,0]]
                r2 = np.sum(r*offf, axis=-1)[..., None] * offf
                r = r.astype(np.float)
                r -= r2

                fig.suptitle("off offset component of detected shifts")


            mags = np.linalg.norm(r, axis=-1)
            plot = mags < thresh
            ax[-1].imshow(abs(images[im]), cmap='gray')
            axim = ax[-1].quiver(l[plot, 1] + 32,
                            l[plot, 0] + 32,
                            r[plot, 1],
                            -r[plot, 0],
                            mags[plot],
                            )

            pts = (np.array(images[im].shape) // 2) + of
            ax[-1].plot(pts[:, 1], pts[:, 0], 'r')
            ax[-1].set_title('Comparison image {}'.format(im))


            cbar = fig.colorbar(axim, ax=ax)
            cbar.set_label('Magnitude of shift')

        plt.show()
        # make a dictionairy of axes, if doesnt exist create


class AbstractRegistration:  # this will merit being a class eventually!
    def __init__(self, threads=(cpu_count() - 2),
                 windowsize=64,
                 debug=False, ):
        """
        Notes: Stores the stateful info about the function.
            In practise, this is limited to the comparison function used.
        Args:
            threads: Number of logical threads to use
            windowsize: comparison window size to run the registration with
        """
        if threads > 1:
            if not ray.is_initialized():
                ray.init(ignore_reinit_error=True,
                         num_cpus=cpu_count())
        self.threads = threads
        self.windowsize = windowsize
        self.comparison_fn = lambda x: x
        self.preprocess_fn = lambda x: x
        # smack the plan generation here?

        self.thresh = 1200
        self.debug = debug

    def __call__(self, images, searches, comparisons=None, offsets=None):
        """
        Notes:
            This is the base functionality for the pixel and sub pixel
            registration advances interfaces.

            All non-stated inputs can be put here.

        Args:
            images: The image(s) to be searched. can be pre concatenated,
                or can be a list of ims.
            searches: The search to be performed, in the form of a list of
                arrays.
                IMPORTANT: format is ordered by
            comparisons: Indication of the image being compared by the
                registration attempt
            offsets: For searches with multiple estimates, records the
                inbuilt shift of the offset estimates.

        Returns:
            (shift array), fit metric, image comparison

        """

        images = self.preprocess_fn(images)
        # store the ims as read only global memory

        if comparisons is None:
            comparisons = [np.zeros(search.shape[0] - 1, dtype=int)
                           for search in searches]
        if offsets is None:
            offsets = [[np.zeros((search.shape[0] - 1, 2), dtype=int)]
                       for search in searches]

        # chunk everything up for multithreading
        if self.threads > 1:
            im_id = ray.put(images)
            sch_chunk, cmp_chunk, oft_chunk = self.prep_for_multithreading(
                searches,
                comparisons,
                offsets)

            work = zip(sch_chunk, cmp_chunk, oft_chunk)
            comp_ids = [register_ray_chunk.remote(im_id,
                                                  inp,
                                                  self.windowsize,
                                                  self.comparison_fn)
                        for inp in work]
            comparisons = ray.get(comp_ids)

        else:  # compatibility for the single thread implementation
            sch_chunk = [searches]
            cmp_chunk = [comparisons]
            oft_chunk = [offsets]

            work = zip(sch_chunk, cmp_chunk, oft_chunk)

            comps = [register_chunk(images,
                                    inp,
                                    self.windowsize,
                                    self.comparison_fn)
                     for inp in work]
            comparisons = comps

        # then we can unzip the comparisons here
        # now multithreading should be transparent to the inputs

        results = []
        for result in comparisons:
            results.extend(result)

        if self.debug:
            debug_quiver_plot(images=images,
                              searches=searches,
                              results=results,
                              thresh=self.thresh,
                              mode='virt',
                              offsets=offsets, )
        # '''
        return results

    def prep_for_multithreading(self, searches, comparisons, offsets, ):
        """
        Notes: splits the search into chuncks based on a sorted ordering.

        Args:
            searches: the main point n, and m alternate points to search in
            comparisons: additional data about comparisons if necessary
            offsets: the offsets in the m alternate search points

        Returns:
            everything in multi-threadable chunks
        """

        # '''

        sliced_search = np.array_split(searches, self.threads)
        sliced_comprs = np.array_split(comparisons, self.threads)
        sliced_offsts = np.array_split(offsets, self.threads)

        '''


        # work out the inds to split along
        x_ind = np.array([search[0, 0] for search in searches])
        _, uniq_ind = np.unique(x_ind, return_index=True)

        if len(uniq_ind) < self.threads:
            logging.critical(
                "More threads than easy slices - limiting threading.")
            logging.critical("This is bugged atm: you are warned")

        filter_split = [split for split in
                        np.array_split(uniq_ind, self.threads) if np.any(split)]
        split_ind = [cords[0] for cords in filter_split] + [(len(searches))]

        # split the lists
        sliced_search = list_slicer(searches, split_ind)
        sliced_comprs = list_slicer(comparisons, split_ind)
        sliced_offsts = list_slicer(offsets, split_ind)

        #'''

        return sliced_search, sliced_comprs, sliced_offsts


################################################################################
# something to slice plans

def slice_list(inp_list, slice_points):
    items = len(slice_points) - 1
    returned_list = [None] * items
    for i in range(items):
        returned_list[i] = inp_list[slice_points[i]:slice_points[i + 1]]
    return returned_list


def search_chunk_reslice(search_chunk, ind):
    # accounts for the changing start point of the new arrays.
    return [
        [
            search + [ind_arr, 0]
            for search in searches
        ]
        for searches, ind_arr in zip(search_chunk, ind)
    ]


def slice_image(search_chunks, threshold, window_size):
    """
    Args:
        search_slice: a single slice of a work list: form list
        threshold: the maximum value of the overall image

    Returns:
        a slice that will pull from certian bounds
    """
    slices = [None] * len(search_chunks)
    adjust = [None] * len(search_chunks)

    for idx, search_slice in enumerate(search_chunks):
        start = np.min(search_slice[0][:, 0])
        end = np.max(search_slice[-1][:, 0])
        if end + window_size > threshold:
            logging.debug("slices outside image attempted")

        slices[idx] = slice(start, end + window_size)
        adjust[idx] = -start

    return slices, adjust


################################################################################
# Usable sub classes for specific implementations.
class PixelRegistration(AbstractRegistration):
    def __init__(self, threads=cpu_count(), windowsize=64, debug=False):
        super(PixelRegistration, self).__init__(threads=threads,
                                                windowsize=windowsize,
                                                debug=debug)
        self.comparison_fn = px.CPS_stack


class SubPxRegistration(AbstractRegistration):
    def __init__(self, threads=cpu_count(), windowsize=64, debug=False,
                 **kwargs):
        super(SubPxRegistration, self).__init__(threads=threads,
                                                windowsize=windowsize,
                                                debug=debug)
        mode = kwargs.get('mode', 'Amir')

        self.thresh = 1
        if mode == 'Amir':

            scaling_af = 6
            a_f = 4 * (windowsize // scaling_af)
            fit_size = windowsize - a_f  # 24 is a magic number from Amir
            AA = spx.calc_AA((fit_size, fit_size))

            subpx_fn = lambda u, v, x, y, z: spx.Amir_fit(u, v, x, y, z, AA=AA)
            self.comparison_fn = subpx_fn
        elif mode == 'SVD':
            self.comparison_fn = spx.SVD_fit
        else:
            raise ValueError(mode + " is not a valid subpx registration "
                                    "method")

        # self.preprocess_fn = lambda x: px.SG_convolution(median_filter(x, 5))

# I should integrate the search helper into here

# then it would be way faster to just

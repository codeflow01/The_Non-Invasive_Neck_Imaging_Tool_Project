import numpy as np


def standard_grid_search(imshape, windowsize, steps=None, stride=None,
                         cams=None):
    """
    Notes: Defines a standard grid over an image to search on
    Args:
        imshape: shape of the images
        steps: number of steps along longest dimension
        windowsize: the size of the comparison window

    Returns:

    """
    if cams is None:
        cams = [0, 1]


    if not steps is None and not stride is None:
        raise ValueError('Only one of step and stride can be defined at once')
    if stride is None:
        stride = 32

    if steps is not None:
        interwindow_stride = np.max((np.array(imshape) - windowsize) // steps)
    else:
        interwindow_stride = stride

    if interwindow_stride < 1:
        raise ValueError(f"more steps requested ({steps}) than valid pixels")
    n_steps = (np.array(imshape) - windowsize) // interwindow_stride + 1
    grid_start = 0 # windowsize // 2
    #
    x_ims = range(grid_start,
                  ((n_steps[0]) * interwindow_stride),
                  interwindow_stride)
    y_ims = range(grid_start,
                  ((n_steps[1]) * interwindow_stride),
                  interwindow_stride)

    search_pts = np.fliplr(np.array(np.meshgrid(y_ims, x_ims)).reshape(2, -1).T)

    search_list = [np.block([[pt, cams[0]], [pt, cams[1]]])
                   for pt in search_pts]

    return search_list




def subpixel_search_update(old_search, results, cull_implausible=False):
    """
    Notes: Used to update a search to be used in sub pixel checking
        The update assumes an initial uv0 = uv1 relationship
        It *will not* work for multicamera systems
    Args:
        search: the previously used search
        results: the search results
        imshape: The size of the image that is being searched on
    Returns:
    """

    new_search = []
    used_results = []

    for old_point, result in zip(old_search, results):

        comp_point = old_point[0, :]
        searchlet = [comp_point]
        cam_coord = np.unique(old_point[1:, -1])

        for cam_result, im in zip(result, cam_coord):
            new_point = comp_point - np.append(cam_result[0], 0)
            new_point[-1] = im
            searchlet.append(new_point)
        searchlet = np.array(searchlet)
        if not np.any(searchlet < 0) and cull_implausible:
            new_search.append(searchlet)
            used_results.append(result)
        elif not cull_implausible:
            new_search.append(searchlet)

    if cull_implausible:
        return new_search, used_results
    return new_search


def convert_list_search(search_list, imshape, n_ims):
    full_search = []
    for item in search_list:
        search_item = np.stack(
            [item + i * imshape[1] for i in range(n_ims + 1)])
        full_search.append(search_item)

    return full_search

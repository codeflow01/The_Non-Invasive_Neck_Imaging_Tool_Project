import logging
from multiprocessing import cpu_count
import numpy as np
from matplotlib import pyplot as plt
from roipoly import RoiPoly

from .search_objects import PixelRegistration, SubPxRegistration
from .search_methods import *
from .utils import *



def register_images(im1, im2, plot=True,
                    threads=None,
                    stride=None,
                    windowsize=32,
                    thresh=16,
                    steps= None,
                    ROI = None,
                    save = False):
    """
    Args:
        im1: The initial image
        im2: The image to register to
        plot: Whether or not to plot the results
        threads: Logical threads to parellelise to
        steps: The number of comparisons along the largest axis
        stride: the distance between successive windows./
        windowsize: The size of the comparison window
        ROI:
    Returns:

    """

    run_params = {
        'stride':stride,
        'windowsize':windowsize,
        'steps':steps
    }

    if isinstance(im1, str):
        run_params['imfile_1'] = im1
        im1 = read_image(im1)

    if isinstance(im2, str):
        run_params['imfile_2'] = im2
        im2 = read_image(im2)

    if steps is not None and stride is not None:
        raise ValueError('Only one of step and stride can be defined at once')
    if stride is None and steps is None:
        stride = 32

    # convert to numpy and check matching images
    im1, im2 = np.asarray(im1), np.asarray(im2)
    assert im1.shape == im2.shape, "Input image shapes should be equal"
    # rescale to greyscale
    if im1.ndim >= 2:
        im1 = np.mean(im1.reshape(*im1.shape[:2], -1), axis=-1)
        im2 = np.mean(im2.reshape(*im2.shape[:2], -1), axis=-1)
    roi_offset = None
    if ROI is not None:
        if ROI == 'pick':
            # write ROI picking script
            roi = None
            while roi is None:
                fig, ax = plt.subplots()
                ax.set_title('Click to place point, double click to finish')
                if im1.shape[0] > 1000:
                    # high resolution images cause performance issues
                    d_factor = im1.shape[0] // 1000
                    temp_im = downsample_valid(im1, d_factor)
                else:
                    temp_im = im1
                    d_factor = 1

                ax.imshow(temp_im, cmap='gray')

                r = RoiPoly(color='r')
                if len(r.x) < 4:
                    logging.critical('Please select at least 4 points')
                else:
                    roi = [min(r.y), max(r.y), min(r.x), max(r.x)]
                    roi = [int(p) for p in roi]
                    if im1.shape[0] > 500:
                        roi = [p * d_factor for p in roi]
        else:
            if isinstance(ROI, str):
                raise ValueError('"pick" is the only accepted string')

        if isinstance(ROI, list) or isinstance(ROI, np.ndarray):
            roi = ROI
            #check validity
        if is_valid_roi(roi, im1):
            slice_0, slice_1 = slice(roi[0], roi[1]), slice(roi[2], roi[3])

            im1 = im1[slice_0, slice_1]
            im2 = im2[slice_0, slice_1]

            plotting= False
            if plotting:
                plt.imshow(im1, cmap='gray')
                plt.title('Extracted region: now running registration')
                plt.show(block=False)

            roi_offset = roi[0], roi[2]

        run_params['ROI'] = roi

    # set up multithreading limits
    if threads is None:
        threads = max(cpu_count() - 2, 1)  # leave 2 threads by default
    if threads >= (cpu_count() + 1):
        print(cpu_count())
        raise ValueError("Not enough logical cores for {} threads".format(
            threads))

    ############################################################################
    # Define a standard grid search over the images
    search_list = standard_grid_search(imshape=im1.shape,
                                       windowsize=windowsize,
                                       steps=steps,
                                       stride=stride)

    # ims = np.concatenate((im1, im2), axis=1)
    ims = [im1, im2]
    # perform a pixel level registration
    pixel = PixelRegistration(threads=threads, windowsize=windowsize)
    pixel_res = pixel(images=ims, searches=search_list)

    # update the new search list with the results.
    sub_px_search, used_px_res = subpixel_search_update(search_list,
                                           pixel_res,
                                        cull_implausible=True)

    # update and perform a subpixel level registration
    sub_px = SubPxRegistration(threads=threads,
                               windowsize=windowsize,
                               # mode='SVD',
                               )
    sub_pxres = sub_px(images=ims, searches=sub_px_search)

    ############################################################################
    # add the two shifts together to return the results.
    a, b = -1, 1
    results = []
    for px_result, subpx_result in zip(used_px_res, sub_pxres):
        total_shift = a * px_result[0][0] + b * subpx_result[0][0]
        results.append(total_shift)
    results = np.array(results)

    locs = np.array(sub_px_search)[:, 0, :]
    # plot the results
    if plot:
        result_plotter(im1, results, locs, thresh=thresh, windowsize=windowsize)
        plt.show()
    if roi_offset is not None:
        locs += list(roi_offset) + [0]
    if save:
        save_results(results, locs, run_params)
    return results, locs

def is_valid_roi(roi, image):
    if not len(roi)==4:
        raise ValueError('roi provided is not of the form [x_min, x_max, '
                         'y_min, y_max]')
    if roi[0] < 0 or roi[2] < 0:
        raise ValueError('roi had negative values')
    if roi[1] >= image.shape[0] or roi[3] >= image.shape[1]:
        raise ValueError('roi extended outside of provided image')
    if roi[0] >= roi[1] or roi[2] > roi[3]:
        raise ValueError('roi has misordered inputs')
    if (roi[1] - roi[0]) < 32 or (roi[3] - roi[2]) < 32:
        raise ValueError('configured roi is too small')
    return True



def result_plotter(im, results, loc, thresh=64, scale=None, windowsize = 0):
    """
    Notes: Plots the results nicely
    Args:
        im: initial image
        results: the results vector
        loc: the locations of the comparisons
        thresh: a threshold for removing overly large deformations
        scale:

    Returns:

    """

    plt.figure()
    res = results.squeeze()

    mags = np.linalg.norm(res, axis=1)
    mask = mags < thresh

    plt.imshow(abs(im), cmap=plt.cm.gray)
    ax = plt.quiver(loc[mask, 1] + windowsize/2,
                    loc[mask, 0] + windowsize/2,
                    res[mask, 1],
                    -res[mask, 0], mags[mask],
                    scale=scale,
                    )
    plt.xlabel("x Pixels")
    plt.ylabel("y Pixels")
    cbar = plt.colorbar(ax)
    cbar.set_label('Magnitude of shift')
